# tachyonsburgermenu2
Simple Mobile Responsive Burger Menu using Tachyons CSS (or sass), Full size screens displays all items on right (or left) and reduces nicely to Mobile Burger Bars menu on Tablets and Phones. CSS & Javascript with a small stylesheet and link to Tachyons CDN.

Fast and responsive, easy to use and customise. Fine for small to medium sites.

Change the items color from pure white by changing opacity in .main-nav. (ie, a bit greyer), for pure white comment it out.

Change Logo/Brand size by adding class and font-size/whatever, or add a logo image (commented out)

Useful alternative to Bootstrap with just a small javascript file.

#To Do, create Wordpress Version for Sage 9/Blade Views. Add media query to hide logo between 505 & 668px


# picniccssmobilemenu
Responsive Nav Menu using pure css (no javascript) with Picnic css base. Adapted from Picnic base styles.
Fast, responsive, media queries for mobile and desktop views. Easy to style and use in Wordpress builds.

All files included. No imports necessary.
